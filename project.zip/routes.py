
from typing import List
from fastapi import APIRouter
import numpy as np
import pandas as pd
from pydantic import BaseModel
from models.price_estimation import PriceEstimator


# Load and use the model for predictions
loaded_model = PriceEstimator.load_model("price_estimation_model.pkl")

router = APIRouter()


class PriceEstimationRequest(BaseModel):
    rating: float
    bathrooms: int
    year_built: int
    bedrooms: int
    size: float
    latitude: float
    longitude: float
    rentType: str


class PriceEstimationResponse(BaseModel):
    predicted_price: List[float]


@router.post("/estimate-price", response_model=PriceEstimationResponse)
async def estimate_price(request: PriceEstimationRequest):
    new_data = pd.DataFrame([request.model_dump()])
    predicted_price = loaded_model.estimate(new_data)
    predicted_price_list = np.expm1(predicted_price).tolist()
    return PriceEstimationResponse(predicted_price=predicted_price_list)


@router.post("/recommendations")
async def recommendations():
    pass
