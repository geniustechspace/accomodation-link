## ACCOMODATION LINK
A recommdation and price estimation backend service for accomodation-link, a web app for finding and procuring accomodation
